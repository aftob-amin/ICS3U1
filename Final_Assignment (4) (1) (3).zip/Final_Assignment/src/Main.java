import java.net.MalformedURLException;

//This will launch the game
public class Main {

	public static void main(String[] args) throws MalformedURLException {
		new TitlePage();

	}

}