import java.io.File;
import java.io.IOException;

import javax.sound.sampled.*;

public class Volume {
    public static void main(String[] args) {
        try {
            // Open an audio input stream from a file
            File soundFile = new File("");
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);

            // Get a clip object for the audio input stream
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);

            // Play the audio clip
            clip.start();
        } catch (UnsupportedAudioFileException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
    }
}
