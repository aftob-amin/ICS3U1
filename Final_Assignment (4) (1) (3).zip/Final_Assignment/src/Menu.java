import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

//Main Menu GUI
public class Menu {
	
	// Variable declarations for the Main Menu GUI.
	JFrame gui = new JFrame();
	Container con;
	JPanel textPanel, inputPanel;
	JLabel textLabel, title;
	JTextField jtf;
	JButton instruct;
	JButton exit;
	JButton game;
	JButton setting;

	//Main code for Main Menu GUI.
	public Menu() {
		
		//GUI Size and background
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(900, 800);
		gui.getContentPane().setLayout(null);
		gui.setVisible(true);
		gui.setTitle("Tic Tac Toe");
		gui.setResizable(false);
		ImageIcon logo = new ImageIcon("logo.jpg");
		gui.setIconImage(logo.getImage());

		gui.getContentPane().setBackground(Color.black);
		con = gui.getContentPane();
		
		//GUI Border Title
		gui.setTitle("Tic Tac Toe - Main Menu");

		//Image Icon
		ImageIcon logo1 = new ImageIcon("Image/index.png");
		gui.setIconImage(logo1.getImage());

		//GUI Main Menu Title
		title = new JLabel();
		title.setText("Main Menu");
		title.setFont(new Font("Trebuchet MS", Font.BOLD, 100));
		title.setBounds(205, -24, 499, 295);
		title.setForeground(Color.white);

		inputPanel = new JPanel();
		inputPanel.setBounds(190, 550, 500, 50);
		inputPanel.setBackground(Color.black);
		inputPanel.setLayout(new GridLayout(1, 2));

		//Play Button
		game = new JButton("PLAY");
		game.setBounds(300, 295, 300, 75);
		game.setFocusable(false);
		game.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		game.setBackground(Color.white);
		game.setForeground(Color.black);
		game.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Play play = new Play();
				play.setVisible(true);
				gui.dispose();
			}
		});
	
		//Instructions Button
		instruct = new JButton("INSTRUCTIONS");
		instruct.setBounds(300, 400, 300, 75);
		instruct.setFocusable(false);
		instruct.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		instruct.setBackground(Color.white);
		instruct.setForeground(Color.black);
		instruct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Instructions();
				gui.dispose();
			}
		});
		
		//Exit Button
		exit = new JButton("EXIT");
		exit.setBounds(300, 600, 300, 75);
		exit.setFocusable(false);
		exit.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		exit.setBackground(Color.white);
		exit.setForeground(Color.black);
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showOptionDialog(null, "Are you sure you want to exit?", "Tic Tac Toe - Exit Confirmation",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (confirm == JOptionPane.YES_OPTION) {
					System.exit(0);

					;
				}
			}
		});
		
		//Setting Button
		setting = new JButton("SETTINGS");
		setting.setBounds(300, 500, 300, 75);
		setting.setFocusable(false);
		setting.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		setting.setBackground(Color.white);
		setting.setForeground(Color.black);
		setting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Settings();
				gui.dispose();
			}
		});

		//This part adds all the Jlabels an Jbuttons to the GUI
		gui.add(game);
		gui.add(instruct);
		gui.add(exit);
		gui.add(setting);
		gui.add(title);

	}
}
