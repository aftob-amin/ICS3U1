import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

//Title page for the main program
public class TitlePage implements ActionListener {
	
	//Start Button
	JFrame gui = new JFrame();
	JButton next = new JButton("Start");
	JLabel name = new JLabel();
	JLabel light_title = new JLabel();
 
	//Title page GUI
	public TitlePage () throws MalformedURLException{
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setLayout(null);
		gui.setVisible(true);
		gui.setTitle("Tic Tac Toe"); 
		gui.setResizable(false);
		
		//Image Icon
		ImageIcon newImage = new ImageIcon("Image/logo.png");
		JLabel newImageLabel = new JLabel(newImage);
		gui.add(newImageLabel);
		newImageLabel.setBounds(180, 0, 520, 600);
		
		ImageIcon logo = new ImageIcon("Image/index.png");
		gui.setIconImage(logo.getImage());
		
		Icon gif = new ImageIcon("gif.gif");
	
	    JLabel gifLabel = new JLabel(gif);
	    gui.getContentPane().setBackground(Color.black);
	  
	    gui.getContentPane().add(gifLabel);

	    gui.pack();
	    
	    gifLabel.setBounds(200,200,400,400);
		gui.setSize(900,800);
		
		//Names of the creators
		name = new JLabel();
		name.setText("By: Aftob and Nirarthana");
		name.setFont(new Font("Trebuchet MS", Font.PLAIN, 30));
		name.setBounds(545, 485, 500,500);
		name.setForeground(Color.white);
		
		//Start button
		next.setBounds(290, 600, 300, 90);
		next.setFocusable(false);
		next.setFont(new Font("Trebuchet MS", Font.BOLD, 50));
		next.addActionListener(this);
		next.setBackground(Color.white);
		next.setForeground(Color.black);
		
		//This part adds all the Jlabels an Jbuttons to the GUI
		gui.add(name);
		gui.add(next);
		gui.add(light_title);
		
			
	}
	// This section allows you to open the Main Menu Page
	public void actionPerformed(ActionEvent e) {	
			new Menu();
			gui.dispose();
			}
	
}