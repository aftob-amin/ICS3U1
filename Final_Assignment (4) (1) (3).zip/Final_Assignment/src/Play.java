import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

//GUI for the game 
public class Play {
	
	//Variable Declarations
	private JFrame game_gui;
	private JTextField scoreX;
	private JTextField scoreO;
	private int numX = 0;
	private int numO = 0;
	private String start = "X";
	private int b = 10;
	private int b1 = 10;
	private int b2 = 10;
	private int b3 = 10;
	private int b4 = 10;
	private int b5 = 10;
	private int b6 = 10;
	private int b7 = 10;
	private int b8 = 10;
	private int num = 0;
	public boolean buttonClicked = false;
	
	public void setVisible(boolean gui) {
		game_gui.setVisible(gui);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Play window = new Play();
					window.game_gui.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	//Main Part if the Game
	public Play() {
		initialize();
		score();

	}

	
	private void win() {
		if (b == 1 && b1 == 1 && b2 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b3 == 1 && b4 == 1 && b5 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b6 == 1 && b7 == 1 && b8 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b == 1 && b3 == 1 && b6 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b1 == 1 && b4 == 1 && b7 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b2 == 1 && b5 == 1 && b8 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		}

		else if (b == 1 && b4 == 1 && b8 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		} else if (b2 == 1 && b4 == 1 && b6 == 1) {
			JOptionPane.showMessageDialog(game_gui, "Player X Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numX++;
			scoreX.setText(String.valueOf(numX));
		}
		/////////////////////////////////////////////////////////////
		else if (b == 0 && b1 == 0 && b2 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b3 == 0 && b4 == 0 && b5 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b6 == 0 && b7 == 0 && b8 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b == 0 && b3 == 0 && b6 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b1 == 0 && b4 == 0 && b7 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b2 == 0 && b5 == 0 && b8 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		}

		else if (b == 0 && b4 == 0 && b8 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (b2 == 0 && b4 == 0 && b6 == 0) {
			JOptionPane.showMessageDialog(game_gui, "Player O Wins!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
			numO++;
			scoreO.setText(String.valueOf(numO));
		} else if (num == 9) {
			JOptionPane.showMessageDialog(game_gui, "Tie!", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
		}

	}

	private void score() {
		scoreX.setText(String.valueOf(numX));
		scoreO.setText(String.valueOf(numO));
	}

	private void player() {
		if (start.equalsIgnoreCase("X")) {
			start = "O";
		} else {
			start = "X";
		}
	}

	private void initialize() {
		//GUI Size 
		game_gui = new JFrame();
		game_gui.setTitle("Tic Tac Toe - Play");
		game_gui.setBounds(100, 100, 1200, 600);
		game_gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		game_gui.getContentPane().setLayout(new GridLayout(3, 5, 0, 0));
		game_gui.setResizable(true);

		
		//Icon Image
		ImageIcon logo = new ImageIcon("Image/index.png");
		game_gui.setIconImage(logo.getImage());

		//Panel
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 240, 240));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(4, 4));
		
		
		//Button
		JButton btn = new JButton("");
		btn.setForeground(new Color(128, 128, 128));
		btn.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn.setBackground(Color.WHITE);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b = 1;
					num++;
				} else {
					b = 0;
					num++;
				}
				player();
				win();
				btn.setEnabled(false);

			}

		});
		panel.add(btn, BorderLayout.CENTER);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));

		//Button 1
		JButton btn1 = new JButton("");
		btn1.setForeground(new Color(128, 128, 128));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b1 = 1;
					num++;
				} else {
					b1 = 0;
					num++;
				}
				player();
				win();
				btn1.setEnabled(false);

			}
		});
		btn1.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn1.setBackground(Color.WHITE);
		panel_1.add(btn1, BorderLayout.CENTER);

		//Panel 2
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_2);
		panel_2.setLayout(new BorderLayout(4, 4));

		//Button 2
		JButton btn2 = new JButton("");
		btn2.setForeground(new Color(128, 128, 128));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn2.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b2 = 1;
					num++;
				} else {
					b2 = 0;
					num++;
				}
				player();
				win();
				btn2.setEnabled(false);

			}
		});
		btn2.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn2.setBackground(Color.WHITE);
		panel_2.add(btn2, BorderLayout.CENTER);

		//Panel fo player X
		JPanel Panel_PlayerX = new JPanel();
		Panel_PlayerX.setForeground(Color.WHITE);
		Panel_PlayerX.setBackground(new Color(0, 0, 0));
		Panel_PlayerX.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		game_gui.getContentPane().add(Panel_PlayerX);
		Panel_PlayerX.setLayout(new BorderLayout(0, 0));

		//A Jlabel indicating which player it is on the GUI
		JLabel PlayerX = new JLabel("Player X:");
		PlayerX.setForeground(new Color(255, 255, 255));
		PlayerX.setFont(new Font("Trebuchet MS", Font.BOLD, 54));
		Panel_PlayerX.add(PlayerX, BorderLayout.CENTER);

		//Panel for player X score
		JPanel Panel_PlayerXNum = new JPanel();
		Panel_PlayerXNum.setForeground(Color.WHITE);
		Panel_PlayerXNum.setBackground(Color.BLACK);
		Panel_PlayerXNum.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		game_gui.getContentPane().add(Panel_PlayerXNum);
		Panel_PlayerXNum.setLayout(new BorderLayout(0, 0));

		//Text field to show score for player X
		scoreX = new JTextField();
		scoreX.setForeground(Color.WHITE);
		scoreX.setBackground(Color.BLACK);
		scoreX.setFont(new Font("Trebuchet MS", Font.BOLD, 80));
		scoreX.setHorizontalAlignment(SwingConstants.CENTER);
		scoreX.setText("0");
		Panel_PlayerXNum.add(scoreX);
		scoreX.setColumns(10);
		scoreX.setFocusable(false);

		//Panel 3
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_3);
		panel_3.setLayout(new BorderLayout(4, 4));

		//Button 3
		JButton btn3 = new JButton("");
		btn3.setForeground(new Color(128, 128, 128));
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn3.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b3 = 1;
					num++;
				} else {
					b3 = 0;
					num++;
				}
				player();
				win();
				btn3.setEnabled(false);

			}
		});
		btn3.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn3.setBackground(Color.WHITE);
		panel_3.add(btn3, BorderLayout.CENTER);

		//Panel 4
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_4);
		panel_4.setLayout(new BorderLayout(4, 4));

		//Button 4
		JButton btn4 = new JButton("");
		btn4.setForeground(new Color(128, 128, 128));
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn4.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b4 = 1;
					num++;
				} else {
					b4 = 0;
					num++;
				}
				player();
				win();
				btn4.setEnabled(false);

			}
		});
		btn4.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn4.setBackground(Color.WHITE);
		panel_4.add(btn4, BorderLayout.CENTER);

		//Panel 5
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_5);
		panel_5.setLayout(new BorderLayout(0, 0));

		//Button 5
		JButton btn5 = new JButton("");
		btn5.setForeground(new Color(128, 128, 128));
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn5.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b5 = 1;
					num++;
				} else {
					b5 = 0;
					num++;
				}
				player();
				win();
				btn5.setEnabled(false);

			}
		});
		btn5.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn5.setBackground(Color.WHITE);
		panel_5.add(btn5, BorderLayout.CENTER);

		//Panel for Player O
		JPanel Panel_PlayerO = new JPanel();
		Panel_PlayerO.setForeground(Color.WHITE);
		Panel_PlayerO.setBackground(Color.BLACK);
		Panel_PlayerO.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		game_gui.getContentPane().add(Panel_PlayerO);
		Panel_PlayerO.setLayout(new BorderLayout(0, 0));
		
		//A Jlabel indicating which player it is on the GUI
		JLabel PlayerO = new JLabel("Player O:");
		PlayerO.setBackground(Color.BLACK);
		PlayerO.setForeground(new Color(255, 255, 255));
		PlayerO.setFont(new Font("Trebuchet MS", Font.BOLD, 53));
		Panel_PlayerO.add(PlayerO, BorderLayout.CENTER);

		//Panel for player O score
		JPanel Panel_PlayerONum = new JPanel();
		Panel_PlayerONum.setForeground(Color.WHITE);
		Panel_PlayerONum.setBackground(Color.BLACK);
		Panel_PlayerONum.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		game_gui.getContentPane().add(Panel_PlayerONum);
		Panel_PlayerONum.setLayout(new BorderLayout(0, 0));

		//Text field to show score for player O
		scoreO = new JTextField();
		scoreO.setFont(new Font("Trebuchet MS", Font.BOLD, 80));
		scoreO.setText("0");
		scoreO.setBackground(Color.BLACK);
		scoreO.setForeground(Color.WHITE);
		scoreO.setHorizontalAlignment(SwingConstants.CENTER);
		Panel_PlayerONum.add(scoreO, BorderLayout.CENTER);
		scoreO.setColumns(10);
		scoreO.setFocusable(false);

		//Panel 6
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_6);
		panel_6.setLayout(new BorderLayout(4, 4));

		//Button 6
		JButton btn6 = new JButton("");
		btn6.setForeground(new Color(128, 128, 128));
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn6.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b6 = 1;
					num++;
				} else {
					b6 = 0;
					num++;
				}
				player();
				win();
				btn6.setEnabled(false);

			}
		});
		btn6.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn6.setBackground(Color.WHITE);
		panel_6.add(btn6, BorderLayout.CENTER);

		
		//Panel 7
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_7);
		panel_7.setLayout(new BorderLayout(4, 4));

		//Button 7
		JButton btn7 = new JButton("");
		btn7.setForeground(new Color(128, 128, 128));
		btn7.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn7.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b7 = 1;
					num++;
				} else {
					b7 = 0;
					num++;
				}
				player();
				win();
				btn7.setEnabled(false);

			}
		});
		btn7.setBackground(Color.WHITE);
		panel_7.add(btn7, BorderLayout.CENTER);

		//Panel 8
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		game_gui.getContentPane().add(panel_8);
		panel_8.setLayout(new BorderLayout(4, 4));

		//Button 8
		JButton btn8 = new JButton("");
		btn8.setForeground(new Color(128, 128, 128));
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn8.setText(start);
				if (start.equalsIgnoreCase("X")) {
					b8 = 1;
					num++;
				} else {
					b8 = 0;
					num++;
				}
				player();
				win();
				btn8.setEnabled(false);

			}

		});
		btn8.setFont(new Font("Tahoma", Font.BOLD, 96));
		btn8.setBackground(Color.WHITE);
		panel_8.add(btn8, BorderLayout.CENTER);

		JPanel reset = new JPanel();
		reset.setForeground(Color.BLACK);
		reset.setBackground(Color.BLACK);
		reset.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK));
		game_gui.getContentPane().add(reset);
		reset.setLayout(new BorderLayout(0, 0));

		//Reset Button
		JButton resetbtn = new JButton("Reset");
		resetbtn.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		resetbtn.setBackground(Color.BLACK);
		resetbtn.setForeground(Color.WHITE);
		reset.setFocusable(false);
		resetbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				btn.setText(null);
				btn1.setText(null);
				btn2.setText(null);
				btn3.setText(null);
				btn4.setText(null);
				btn5.setText(null);
				btn6.setText(null);
				btn7.setText(null);
				btn8.setText(null);
				btn.setEnabled(true);
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				b = 100;
				b1 = 100;
				b2 = 100;
				b3 = 100;
				b4 = 100;
				b5 = 100;
				b6 = 100;
				b7 = 100;
				b8 = 100;
				num = 0;
			}
		});

		reset.add(resetbtn, BorderLayout.CENTER);

		JPanel main_menu = new JPanel();
		main_menu.setForeground(Color.WHITE);
		main_menu.setBackground(Color.BLACK);
		main_menu.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		game_gui.getContentPane().add(main_menu);
		main_menu.setLayout(new BorderLayout(0, 0));
		
		
		//Main Menu Button
		JButton main_menubtn = new JButton("Main Menu");
		main_menubtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showOptionDialog(null, "Are you sure you want to go back to Main Menu?",
						"", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (confirm == JOptionPane.YES_OPTION) {
					new Menu();
					game_gui.dispose();
				}
			}
		});
		main_menubtn.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		main_menubtn.setBackground(Color.BLACK);
		main_menubtn.setForeground(Color.WHITE);
		main_menu.add(main_menubtn);
	}

}
