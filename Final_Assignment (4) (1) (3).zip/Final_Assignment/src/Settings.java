import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//Settings GUI
public class Settings {
	JFrame gui = new JFrame();
	Container con;
	JPanel textPanel, inputPanel;
	JLabel textLabel, title;
	JButton volume;
	JButton back;

	public Settings() {
		//Frame Size
		gui.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		gui.setSize(900, 800);
		gui.setLayout(null);
		gui.setVisible(true);
		gui.setTitle("Tic Tac Toe - Settings");
		gui.setResizable(false);
		gui.getContentPane().setBackground(Color.black);
		con = gui.getContentPane();
		
		//Image Icon
		ImageIcon logo1 = new ImageIcon("Image/index.png");
		gui.setIconImage(logo1.getImage());
		
		//Title for the GUI
		title = new JLabel();
		title.setText("Settings");
		title.setFont(new Font("Trebuchet MS", Font.BOLD, 100));
		title.setBounds(270, -230, 650, 650);
		title.setForeground(Color.white);

		inputPanel = new JPanel();
		inputPanel.setBounds(190, 550, 500, 50);
		inputPanel.setBackground(Color.black);
		inputPanel.setLayout(new GridLayout(1, 2));

		//Button for Volume
		volume = new JButton("VOLUME");
		volume.setBounds(290, 300, 300, 75);
		volume.setFocusable(false);
		volume.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		volume.setBackground(Color.white);
		volume.setForeground(Color.black);
		volume.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.dispose();
				new Volume();
			}
		});
		
		//Button for Main Menu
		back = new JButton("MAIN MENU");
		back.setBounds(290, 400, 300, 75);
		back.setFocusable(false);
		back.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
		back.setBackground(Color.white);

		back.setForeground(Color.black);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.dispose();
				new Menu();
			}
		});
		
		//This part adds all the Jlabels an Jbuttons to the GUI
		gui.add(back);
		gui.add(title);
		gui.add(volume);

	}
}
