import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//Instructions GUI
public class Instructions {
	
	// Variable declarations for Instructions.
	JFrame game_gui = new JFrame();
	Container con;
	JPanel textPanel, inputPanel;
	JLabel textLabel, mainTitle1;
	Font normalFont = new Font("Trebuchet MS", Font.PLAIN, 26);
	JButton back;

	//Main code for Instruction GUI.
	public Instructions() {
		
		//GUI Size
		game_gui.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		game_gui.setSize(900, 800);
		game_gui.setLayout(null);
		game_gui.setVisible(true);
		game_gui.setTitle("Tic Tac Toe - Instructions");//A p
		game_gui.setResizable(false);

		game_gui.getContentPane().setBackground(Color.black);
		con = game_gui.getContentPane();
		
		//Image Icon
		ImageIcon newImage = new ImageIcon("Image/Instruct.png");
		JLabel newImageLabel = new JLabel(newImage);
		newImageLabel.setBounds(40, 60, 800, 700);
		
		//This contains the instructions of how to play the game
		ImageIcon logo1 = new ImageIcon("Image/index.png");
		game_gui.setIconImage(logo1.getImage());
		
		//Instructions Title
		mainTitle1 = new JLabel();
		mainTitle1.setText("Instructions");
		mainTitle1.setFont(new Font("Trebuchet MS", Font.BOLD, 80));
		mainTitle1.setBounds(200, -230, 650, 650);
		mainTitle1.setForeground(Color.white);
		
		inputPanel = new JPanel();
		inputPanel.setBounds(190, 550, 500, 50);
		inputPanel.setBackground(Color.black);
		inputPanel.setLayout(new GridLayout(1, 2));

		//Exit Intructions
		back = new JButton("MAIN MENU");
		back.setBounds(680, 680, 200, 75);
		back.setFocusable(false);
		back.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
		back.setBackground(Color.white);
		back.setForeground(Color.black);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				game_gui.dispose();
				new Menu();
			}
		});
		
		//This part adds all the Jlabels an Jbuttons to the GUI
		game_gui.add(mainTitle1);
		game_gui.add(back);
		game_gui.add(newImageLabel);
		

	}
}